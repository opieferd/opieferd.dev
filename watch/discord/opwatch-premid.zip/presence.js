(() => {
"use strict";
var ActivityType = /*#__PURE__*/ function(ActivityType) {
    ActivityType[ActivityType["Playing"] = 0] = "Playing";
    ActivityType[ActivityType["Streaming"] = 1] = "Streaming";
    ActivityType[ActivityType["Listening"] = 2] = "Listening";
    ActivityType[ActivityType["Watching"] = 3] = "Watching";
    ActivityType[ActivityType["Competing"] = 5] = "Competing";
    return ActivityType;
}(ActivityType || {});
function getTimestamps(elementTime, elementDuration) {
    const startTime = Date.now() / 1000 - elementTime;
    const endTime = startTime + elementDuration;
    return [
        Math.floor(startTime),
        Math.floor(endTime)
    ];
}
const presence = new Presence({
    clientId: '1558711400132640918'
});
let frame = null;
function readState() {
    const section = document.querySelector('#player-section');
    if (!section || section.hidden) return null;
    try {
        const state = JSON.parse(section.dataset.discordPresence || 'null');
        return state?.version === 1 && state.enabled && state.active ? state : null;
    } catch  {
        return null;
    }
}
function matchesPlayer(url, playerUrl) {
    try {
        return new URL(url).href === new URL(playerUrl || '').href;
    } catch  {
        return false;
    }
}
presence.on('iFrameData', (data)=>{
    const state = readState();
    if (state && data && matchesPlayer(data.url, state.playerUrl)) frame = data;
});
presence.on('UpdateData', ()=>{
    const state = readState();
    if (!state?.title || !state.playerUrl) {
        frame = null;
        return presence.clearActivity();
    }
    const label = state.mediaType === 'tv' ? `S${state.season || 1} E${state.episode || 1}` : 'Movie';
    const data = {
        type: 3,
        details: state.title.slice(0, 128),
        state: `${label} · opieferd.dev/watch`,
        largeImageKey: state.image || 'https://opieferd.dev/favicon.png',
        largeImageText: state.title.slice(0, 128),
        buttons: [
            {
                label: 'Watch on opieferd.dev',
                url: 'https://opieferd.dev/watch/'
            }
        ]
    };
    const now = Date.now();
    const fresh = (value)=>value && Number.isFinite(value.updatedAt) && now >= value.updatedAt && now - value.updatedAt < 15000;
    const video = frame && matchesPlayer(frame.url, state.playerUrl) && fresh(frame.video) ? frame.video : fresh(state.playback) ? state.playback : null;
    if (video?.paused === true) {
        data.state = `Paused · ${label}`;
    } else if (video?.paused === false && Number.isFinite(video.currentTime) && video.currentTime >= 0 && Number.isFinite(video.duration) && video.duration > video.currentTime) {
        const position = Math.min(video.duration, video.currentTime + (now - video.updatedAt) / 1000);
        if (position < video.duration) [data.startTimestamp, data.endTimestamp] = getTimestamps(position, video.duration);
    }
    return presence.setActivity(data);
});

})();
